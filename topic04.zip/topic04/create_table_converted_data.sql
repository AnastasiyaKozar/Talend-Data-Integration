create table converted_data (
      file_name varchar2(100),
      content blob
  );
