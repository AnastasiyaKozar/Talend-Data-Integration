drop table CUSTOMERS_CL;
  
drop table products_cl;

drop table bad_records;

drop table mpd;

drop table products_dm;

drop table customers_dm;

drop table PAYMENT_METADATA;

drop table monthly_payments;

drop table monthly_payment_dm;
  

  
