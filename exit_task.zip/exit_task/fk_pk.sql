alter table dim_customers
      add constraint pk_cust_id primary key(cust_surr_id); 
      
 alter table dim_products
      add constraint pk_prod_id primary key(prod_surr_id);
      
  
  
 alter table monthly_payment_dm
      add constraint fk_prod_id FOREIGN key(prod_surr_id)
    references dim_products(prod_surr_id);
    
  
 alter table monthly_payment_dm
      add constraint fk_cust FOREIGN key(cust_surr_id)
    references dim_customers(cust_surr_id);
    


    