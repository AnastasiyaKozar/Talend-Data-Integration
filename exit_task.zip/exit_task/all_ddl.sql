CREATE SEQUENCE customers_seq
 START WITH   1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;
 
 CREATE SEQUENCE prod_seq
 START WITH   1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;
 
 create table products_cl(
  product_id number(5,0) not null,
  product_name varchar2(200),
  company_name varchar2(150),
  price float,
  warehouse_location_state varchar2(15)
  );
  
  
create table products_dm(
  product_id number(5,0) not null,
  prod_surr_id number(5,0) not null,
  product_name varchar2(200) ,
  company_name varchar2(150),
  price float,
  warehouse_location_state varchar2(15) 
  );
  
create table dim_products(
  prod_surr_id number(5,0) not null,
  product_name varchar2(200) ,
  company_name varchar2(150),
  price float,
  warehouse_location_state varchar2(15) 
  );
  
create table customers_cl(
      customer_id number(5,0),
      name varchar2(100),
      user_name varchar2(100),
      email varchar2(100),
      date_birth date,
      street_address varchar2(100),
      city varchar2(50),
      country varchar2(50),
      zip varchar2(20) ,
      state varchar2(50) ,
      phone varchar2(50) 
  );
  
create table customers_dm(
      customer_id number(5,0) not null,
      cust_surr_id number(5,0) not null,
      name varchar2(100) not null,
      user_name varchar2(100) not null,
      email varchar2(100) not null,
      date_birth date not null,
      street_address varchar2(100) not null,
      city varchar2(50) not null,
      country varchar2(50) not null,
      zip varchar2(20) not null,
      state varchar2(50) not null,
      phone varchar2(50) not null
  );
  
  create table dim_customers(
      cust_surr_id number(5,0) not null,
      name varchar2(100) not null,
      user_name varchar2(100) not null,
      email varchar2(100) not null,
      date_birth date not null,
      street_address varchar2(100) not null,
      city varchar2(50) not null,
      country varchar2(50) not null,
      zip varchar2(20) not null,
      state varchar2(50) not null,
      phone varchar2(50) not null
  );
  
  
create table monthly_payments(
      payment_id number(10,0),
      customer_id number(10,0) not null,
      product_id number(10,0) not null,
      transaction_date date("yyyy-MM-dd'T'HH:mm:ss") not null,
      credit_card varchar2(50) not null,
      credit_card_number varchar2(50) not null
  );
  
  
 CREATE TABLE  monthly_payment_dm
  (	"PAYMENT_ID" NUMBER(7,0) not null, 
    "CUST_SURR_ID" NUMBER(7,0) not null, 
    "PROD_SURR_ID" NUMBER(7,0) not null, 
    "PRICE" FLOAT(126) not null, 
    "TRANSACTION_DATE" DATE not null, 
    "CREDIT_CARD" VARCHAR2(50 BYTE) not null, 
    "CREDIT_CARD_NUMBER" VARCHAR2(50 BYTE) not null, 
    "KPI" NUMBER(2,0) not null
   ); 
  
create table payment_metadata (
      file_name varchar2(100)
  );