
  
create table payment_metadata (
      file_name varchar2(100)
  );
  
